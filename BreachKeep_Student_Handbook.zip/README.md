# The Defender's Compass: BreachKeep Student Cybersecurity Teaching Handbook

Welcome to the **BreachKeep Student Cybersecurity Teaching Handbook**!

This package contains everything you need to read, view, or regenerate the comprehensive student cybersecurity guide covering **Networking (Signals)**, **Web Application Security (The Trading Post)**, and **Defensive Engineering (The Forge)**.

---

## 📖 How to View the Handbook

### 1. Print / Offline PDF Edition (Recommended)
- Open **`BreachKeep_Student_Handbook.pdf`** in any standard PDF reader (Adobe Acrobat, Preview, Chrome, Edge, Firefox).
- Formatted with dedicated chapter breaks, real-world breach case studies, callout boxes, and syntax-highlighted code.

### 2. Interactive Web / HTML Edition
- Double-click or open **`BreachKeep_Student_Handbook.html`** in any web browser.
- Responsive, self-contained (zero external network dependencies required), with native styling for desktop and mobile reading.

---

## 🛠️ How to Recompile / Edit the Handbook

If you make modifications to the text, styling, or challenge lessons:
1. Ensure Node.js (v18+) is installed.
2. Run:
   ```bash
   node scripts/generate-handbook-pdf.mjs
   ```
   *(Note: Automatic PDF rendering uses Microsoft Edge or Chromium in headless mode).*

---

## 📚 What's Inside

- **The Teacher's Welcome & Mental Model**: Foundations of cybersecurity ethics and systems thinking.
- **Chapter 1: Signals (Networking)**: 10 rooms covering Ports, Nmap scanning, Banner Grabbing, Wireshark packet capture, DNS, HTTP, Protocol Identification, Firewalls, PCAP forensics, and Pivoting.
- **Chapter 2: The Trading Post (Web Security)**: 10 rooms covering Recon, DevTools, Cookies & Session trust, Client-side validation bypasses, IDOR, SQL Injection, Reflected XSS, Security Headers, Stored XSS, and Multi-stage vulnerability chains.
- **Chapter 3: The Forge (Secure Coding)**: 8 rooms covering Parameterized queries, Contextual output encoding, Server-side authorization gates, Strict client boundaries, Defensive headers, Token-bucket rate limiting, Environment secret hygiene, and Holistic defensive audits.
